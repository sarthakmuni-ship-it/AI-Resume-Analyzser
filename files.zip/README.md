# AI Resume Analyzer — Backend

A production-grade FastAPI backend that analyzes resumes against job descriptions using the Groq LLM API.
Returns ATS scores, skill gap analysis, rewritten bullets, and **personalized learning roadmaps** for every missing skill.

---

## Features

| Feature | Details |
|---|---|
| ATS Scoring | Math-backed score with critical / medium / low skill weighting |
| Domain Mismatch Detection | Hard cap of 5–19 for completely unrelated roles |
| Skill Gap Analysis | Every missing skill includes priority, exact resume location, and ATS keyword to add |
| Rewritten Bullets | XYZ-format rewrites with missing keywords woven in naturally |
| Learning Roadmaps | Per-skill: phased plan, free + paid resources, practice projects, quick resume wins |
| Roadmap Caching | LLM called only once per analysis × skill pair |
| History | All scans persisted in SQLite (swap to Postgres with one env var) |

---

## Project Structure

```
ai_resume_analyzer/
├── main.py                         ← Uvicorn entry point
├── requirements.txt
├── .env.example
├── alembic/                        ← DB migrations
│   └── env.py
└── app/
    ├── api/
    │   └── v1/
    │       ├── router.py           ← Wires all routers under /api/v1
    │       └── endpoints/
    │           ├── analysis.py     ← POST /analyze/, POST /analyze/text, GET/DELETE /history
    │           └── roadmap.py      ← POST/GET /roadmap/{analysis_id}/{skill_name}
    ├── core/
    │   ├── config.py               ← Pydantic Settings (reads .env)
    │   └── application.py          ← FastAPI factory + CORS + lifespan
    ├── db/
    │   ├── base.py                 ← Declarative base + model imports for Alembic
    │   └── session.py              ← Async engine + get_db() dependency
    ├── models/
    │   ├── analysis.py             ← AnalysisHistory ORM model
    │   └── roadmap.py              ← SkillRoadmap ORM model
    ├── schemas/
    │   └── __init__.py             ← All Pydantic v2 request/response schemas
    ├── services/
    │   ├── llm_service.py          ← ATS analysis prompt + Groq call + score override
    │   ├── roadmap_service.py      ← Roadmap prompt + Groq call
    │   ├── pdf_service.py          ← PyMuPDF text extraction
    │   └── txt_service.py          ← UTF-8 / latin-1 text decoding
    └── utils/
        ├── analysis_crud.py        ← DB helpers for AnalysisHistory
        └── roadmap_crud.py         ← DB helpers for SkillRoadmap (includes cache check)
```

---

## Quick Start

```bash
# 1. Clone and enter the project
cd ai_resume_analyzer

# 2. Create a virtual environment
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure environment
cp .env.example .env
# Edit .env — set GROQ_API_KEY at minimum

# 5. Run (tables are auto-created on first start)
uvicorn main:app --reload
```

Open **http://localhost:8000/docs** for the interactive API explorer.

---

## API Reference

### Analysis

| Method | Path | Description |
|---|---|---|
| `POST` | `/api/v1/analyze/` | Upload PDF or TXT resume |
| `POST` | `/api/v1/analyze/text` | Paste raw resume text |
| `GET` | `/api/v1/analyze/history` | List all past analyses |
| `GET` | `/api/v1/analyze/history/{id}` | Get single analysis |
| `DELETE` | `/api/v1/analyze/history/{id}` | Delete analysis + linked roadmaps |

### Roadmaps

| Method | Path | Description |
|---|---|---|
| `POST` | `/api/v1/roadmap/{analysis_id}/{skill_name}` | Generate (or return cached) roadmap |
| `GET` | `/api/v1/roadmap/{analysis_id}` | List all roadmaps for an analysis |
| `GET` | `/api/v1/roadmap/{analysis_id}/{skill_name}` | Fetch specific roadmap |
| `DELETE` | `/api/v1/roadmap/item/{roadmap_id}` | Delete a roadmap |

---

## How the Score Improves After Adding Keywords

1. Run analysis → receive `missing_skills` list, each with a `suggested_keyword`
2. Add those exact keywords to your resume (the `recommended_location` tells you where)
3. Use the `rewritten_bullets` directly — they already contain the missing keywords
4. Re-run analysis → missing skills become matched skills → fewer deductions → higher score

Each roadmap's `quick_wins` list also tells you the exact phrase to paste and which section, with an estimated score impact.

---

## Switching to PostgreSQL

```env
# .env
DATABASE_URL=postgresql+asyncpg://user:password@localhost:5432/resume_analyzer
```

```bash
pip install asyncpg
alembic upgrade head
```

---

## Environment Variables

| Variable | Required | Default | Description |
|---|---|---|---|
| `GROQ_API_KEY` | ✅ | — | Your Groq API key |
| `DATABASE_URL` | ✅ | SQLite | Async SQLAlchemy connection string |
| `GROQ_MODEL` | ❌ | `llama3-70b-8192` | Groq model to use |
| `GROQ_TIMEOUT` | ❌ | `90` | HTTP timeout in seconds |
| `APP_ENV` | ❌ | `development` | `development` or `production` |
| `ALLOWED_ORIGINS` | ❌ | localhost ports | CORS origins (JSON array string) |
