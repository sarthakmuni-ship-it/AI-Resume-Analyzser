"""
app/models/analysis.py
──────────────────────
SQLAlchemy model for storing ATS analysis results.
"""
from sqlalchemy import Column, Integer, String, Text, Float, JSON, DateTime, Boolean
from sqlalchemy.sql import func
from app.db.base import Base


class AnalysisHistory(Base):
    __tablename__ = "analysis_history"

    id              = Column(Integer, primary_key=True, index=True)
    filename        = Column(String(255), nullable=False)
    job_description = Column(Text, nullable=False)

    # ATS result fields
    match_score     = Column(Float,   nullable=False, default=0.0)
    domain_match    = Column(Boolean, nullable=False, default=True)
    matched_skills  = Column(JSON,    nullable=True,  default=list)
    missing_skills  = Column(JSON,    nullable=True,  default=list)
    ats_feedback    = Column(JSON,    nullable=True,  default=list)
    rewritten_bullets = Column(JSON,  nullable=True,  default=list)
    score_breakdown = Column(JSON,    nullable=True,  default=dict)

    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
