"""
app/models/roadmap.py
─────────────────────
Stores generated learning roadmaps per skill, linked to an analysis.
Roadmaps are cached by skill name so repeated requests don't re-call the LLM.
"""
from sqlalchemy import Column, Integer, String, JSON, DateTime, ForeignKey, Text
from sqlalchemy.sql import func
from app.db.base import Base


class SkillRoadmap(Base):
    __tablename__ = "skill_roadmaps"

    id              = Column(Integer, primary_key=True, index=True)

    # Which analysis spawned this roadmap
    analysis_id     = Column(Integer, ForeignKey("analysis_history.id", ondelete="CASCADE"), nullable=False, index=True)

    # The missing skill this roadmap targets
    skill_name      = Column(String(255), nullable=False, index=True)
    skill_priority  = Column(String(20),  nullable=False, default="medium")

    # Full roadmap payload from the LLM
    overview        = Column(Text,  nullable=True)
    estimated_weeks = Column(Integer, nullable=True)
    phases          = Column(JSON,  nullable=True, default=list)   # list of phase objects
    free_resources  = Column(JSON,  nullable=True, default=list)
    paid_resources  = Column(JSON,  nullable=True, default=list)
    practice_projects = Column(JSON, nullable=True, default=list)
    quick_wins      = Column(JSON,  nullable=True, default=list)   # things to add to resume NOW

    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
