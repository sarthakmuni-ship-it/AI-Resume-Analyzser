"""
app/schemas/
────────────
All Pydantic v2 request / response models.
"""
from __future__ import annotations
from typing import List, Optional, Any
from datetime import datetime
from pydantic import BaseModel, Field


# ════════════════════════════════════════════════════════
# Analysis schemas
# ════════════════════════════════════════════════════════

class ScoreBreakdown(BaseModel):
    base_score:           int = 100
    critical_deductions:  int = 0
    medium_deductions:    int = 0
    low_deductions:       int = 0
    domain_penalty:       int = 0
    final_score:          int = 0


class MissingSkill(BaseModel):
    skill:                str
    priority:             str = "medium"          # critical | medium | low
    recommended_location: str = ""
    suggested_keyword:    str = ""


class RewrittenBullet(BaseModel):
    original:     str
    rewritten:    str
    skills_added: List[str] = []


class AnalysisResult(BaseModel):
    domain_match:       bool
    match_score:        float
    score_breakdown:    ScoreBreakdown
    matched_skills:     List[str]
    missing_skills:     List[MissingSkill]
    ats_feedback:       List[str]
    rewritten_bullets:  List[RewrittenBullet]


class AnalysisAPIResponse(BaseModel):
    status:         str
    data:           AnalysisResult
    history_id:     int
    extracted_text: Optional[str] = None


# ════════════════════════════════════════════════════════
# History schemas
# ════════════════════════════════════════════════════════

class HistoryRecord(BaseModel):
    id:                 int
    filename:           str
    job_description:    str
    match_score:        float
    domain_match:       bool = True
    matched_skills:     Optional[List[str]]     = []
    missing_skills:     Optional[List[Any]]     = []
    ats_feedback:       Optional[List[str]]     = []
    rewritten_bullets:  Optional[List[Any]]     = []
    score_breakdown:    Optional[Any]           = None
    created_at:         Optional[datetime]      = None

    model_config = {"from_attributes": True}


class HistoryListResponse(BaseModel):
    status: str
    data:   List[HistoryRecord]


class DeleteResponse(BaseModel):
    status:  str
    message: str


# ════════════════════════════════════════════════════════
# Roadmap schemas
# ════════════════════════════════════════════════════════

class RoadmapPhase(BaseModel):
    phase_number:   int
    title:          str
    duration_weeks: int
    goals:          List[str]
    topics:         List[str]
    milestone:      str                          # what you can do/show after this phase


class RoadmapResource(BaseModel):
    title:       str
    url:         str
    type:        str                             # course | book | video | docs | practice
    platform:    str                             # e.g. Coursera, YouTube, official docs
    description: str


class RoadmapQuickWin(BaseModel):
    action:           str    # "Add 'React.js' to your Skills section"
    resume_section:   str    # "Skills"
    expected_impact:  str    # "Moves this skill from missing → matched, +10–15 pts"


class SkillRoadmapResponse(BaseModel):
    id:                 int
    analysis_id:        int
    skill_name:         str
    skill_priority:     str
    overview:           str
    estimated_weeks:    int
    phases:             List[RoadmapPhase]
    free_resources:     List[RoadmapResource]
    paid_resources:     List[RoadmapResource]
    practice_projects:  List[str]
    quick_wins:         List[RoadmapQuickWin]
    created_at:         Optional[datetime] = None

    model_config = {"from_attributes": True}


class RoadmapListResponse(BaseModel):
    status: str
    data:   List[SkillRoadmapResponse]


class RoadmapAPIResponse(BaseModel):
    status: str
    data:   SkillRoadmapResponse
