"""
app/utils/analysis_crud.py
───────────────────────────
All DB operations for AnalysisHistory — keeps endpoint code clean.
"""
from __future__ import annotations
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from app.models.analysis import AnalysisHistory


async def save_analysis(
    db: AsyncSession,
    filename: str,
    job_description: str,
    analysis: dict,
) -> AnalysisHistory:
    record = AnalysisHistory(
        filename          = filename,
        job_description   = job_description,
        match_score       = analysis.get("match_score", 0.0),
        domain_match      = analysis.get("domain_match", True),
        matched_skills    = analysis.get("matched_skills", []),
        missing_skills    = analysis.get("missing_skills", []),
        ats_feedback      = analysis.get("ats_feedback", []),
        rewritten_bullets = analysis.get("rewritten_bullets", []),
        score_breakdown   = analysis.get("score_breakdown", {}),
    )
    db.add(record)
    await db.commit()
    await db.refresh(record)
    return record


async def get_all_analyses(db: AsyncSession) -> list[AnalysisHistory]:
    result = await db.execute(
        select(AnalysisHistory).order_by(AnalysisHistory.created_at.desc())
    )
    return result.scalars().all()


async def get_analysis_by_id(db: AsyncSession, analysis_id: int) -> AnalysisHistory | None:
    result = await db.execute(
        select(AnalysisHistory).filter(AnalysisHistory.id == analysis_id)
    )
    return result.scalars().first()


async def delete_analysis(db: AsyncSession, record: AnalysisHistory) -> None:
    await db.delete(record)
    await db.commit()
