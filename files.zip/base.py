"""
app/db/base.py
──────────────
Declarative base — import all models here so Alembic can discover them.
"""
from sqlalchemy.orm import declarative_base

Base = declarative_base()

# Import models so metadata is populated for create_all / Alembic
from app.models.analysis import AnalysisHistory   # noqa: F401, E402
from app.models.roadmap import SkillRoadmap        # noqa: F401, E402
