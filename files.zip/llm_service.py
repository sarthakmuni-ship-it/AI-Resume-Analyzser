"""
app/services/llm_service.py
────────────────────────────
Calls the Groq API to perform ATS resume analysis.
All prompt logic lives here — nowhere else.
"""
from __future__ import annotations
import json
import httpx

from app.core.config import settings

# ── Groq endpoint ────────────────────────────────────────────────────────────
_GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"


# ════════════════════════════════════════════════════════════════════════════
# Prompt
# ════════════════════════════════════════════════════════════════════════════

def _build_analysis_prompt(resume_text: str, job_description: str) -> str:
    return f"""
You are a brutally strict, domain-aware ATS (Applicant Tracking System) evaluator.
Your job is to compare a Resume against a Job Description and return a precise, math-backed analysis.

═══════════════════════════════════════════════
PHASE 1 — DOMAIN MATCH CHECK (Run this FIRST)
═══════════════════════════════════════════════
Before scoring anything, identify:
- The core profession/industry of the Job Description (e.g., Legal, Medical, Software Engineering, Finance)
- The core profession/industry of the Resume

If these do NOT match (e.g., Software Developer applying for Lawyer, Doctor applying for Data Analyst):
  → domain_match = false
  → match_score MUST be between 5 and 19. No exceptions.
  → matched_skills MUST only include truly transferable skills (e.g., "research", "documentation") — maximum 3.
  → Do NOT match soft skills like "communication" or "teamwork" as domain skills.
  → Proceed to fill all other fields normally.

If they DO match:
  → domain_match = true

═══════════════════════════════════════════════
PHASE 2 — SKILL EXTRACTION (Domain match only)
═══════════════════════════════════════════════
Extract ONLY domain-specific, technical, or role-critical skills from the Job Description.
DO NOT include generic soft skills (communication, teamwork, leadership, etc.) unless the JD explicitly lists them as hard requirements with measurable criteria.

For each skill found in the JD:
- If it exists verbatim or as a clear equivalent in the resume → add to matched_skills
- If it is missing or only vaguely implied → add to missing_skills

Categorize every missing skill:
- "critical": Core requirement; absence alone drops the score significantly (deduct 10–15 pts each)
- "medium":   Important but not a dealbreaker (deduct 5–8 pts each)
- "low":      Nice-to-have (deduct 2–4 pts each)

═══════════════════════════════════════════════
PHASE 3 — SCORE CALCULATION (Show your math)
═══════════════════════════════════════════════
1. Start at 100
2. For each CRITICAL missing skill: subtract 10–15 points
3. For each MEDIUM missing skill:   subtract 5–8 points
4. For each LOW missing skill:      subtract 2–4 points
5. If domain mismatch: cap score between 5–19 regardless of math

The match_score MUST reflect this math precisely.
Populate score_breakdown with the actual numbers used.

═══════════════════════════════════════════════
PHASE 4 — ACTIONABLE FEEDBACK
═══════════════════════════════════════════════
For rewritten_bullets:
- Pick 3–5 weak or generic bullets from the resume
- Rewrite in XYZ format: "Accomplished [X] by doing [Y], resulting in [Z]"
- NATURALLY weave in missing_skills keywords — be honest, do not invent experiences
- Each rewritten bullet must contain at least one keyword from missing_skills

For ats_feedback:
- Give 4–6 specific, actionable points referencing actual resume/JD content
- Cover: keyword density, section structure, formatting, ATS-unfriendly patterns

═══════════════════════════════════════════════
OUTPUT FORMAT — Respond ONLY with valid JSON matching this exact schema.
No markdown fences, no preamble, no extra keys.
═══════════════════════════════════════════════
{{
  "domain_match": true,
  "match_score": 65,
  "score_breakdown": {{
    "base_score": 100,
    "critical_deductions": -20,
    "medium_deductions": -10,
    "low_deductions": -5,
    "domain_penalty": 0,
    "final_score": 65
  }},
  "matched_skills": [
    "Only domain-specific skills found in BOTH the JD and the resume"
  ],
  "missing_skills": [
    {{
      "skill": "Exact skill name from JD",
      "priority": "critical",
      "recommended_location": "Exact section in resume, e.g. Work Experience > TechCorp role",
      "suggested_keyword": "The exact ATS keyword phrase to add"
    }}
  ],
  "ats_feedback": [
    "Specific feedback point referencing actual resume/JD content"
  ],
  "rewritten_bullets": [
    {{
      "original": "Original bullet copied exactly from resume",
      "rewritten": "XYZ-format rewrite with missing keywords woven in naturally",
      "skills_added": ["skill1", "skill2"]
    }}
  ]
}}

Job Description:
{job_description}

Resume:
{resume_text}
""".strip()


# ════════════════════════════════════════════════════════════════════════════
# Score override — deterministic layer on top of LLM score
# ════════════════════════════════════════════════════════════════════════════

def _apply_score_override(result: dict) -> dict:
    ai_score     = float(result.get("match_score", 0))
    domain_match = result.get("domain_match", True)

    # Hard domain-mismatch cap
    if not domain_match:
        result["match_score"] = min(ai_score, 19.0)
        return result

    missing_skills = result.get("missing_skills", [])
    critical = sum(1 for s in missing_skills if s.get("priority") == "critical")
    medium   = sum(1 for s in missing_skills if s.get("priority") == "medium")
    low      = sum(1 for s in missing_skills if s.get("priority") == "low")

    calculated = 100 - (critical * 12) - (medium * 6) - (low * 3)
    calculated = max(20, calculated)           # floor of 20 for domain matches

    # Never inflate above what the LLM calculated
    result["match_score"] = float(min(calculated, ai_score))
    return result


# ════════════════════════════════════════════════════════════════════════════
# Public function
# ════════════════════════════════════════════════════════════════════════════

async def analyze_resume_with_groq(resume_text: str, job_description: str) -> dict:
    """
    Send resume + JD to Groq and return the structured analysis dict.
    Applies deterministic score override before returning.
    """
    headers = {
        "Authorization": f"Bearer {settings.GROQ_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": settings.GROQ_MODEL,
        "messages": [
            {"role": "user", "content": _build_analysis_prompt(resume_text, job_description)}
        ],
        "temperature": settings.GROQ_TEMPERATURE,
        "response_format": {"type": "json_object"},
    }

    async with httpx.AsyncClient(timeout=settings.GROQ_TIMEOUT) as client:
        response = await client.post(_GROQ_URL, headers=headers, json=payload)
        response.raise_for_status()

    data = response.json()

    try:
        content = data["choices"][0]["message"]["content"]
        result  = json.loads(content)
    except (json.JSONDecodeError, KeyError) as e:
        raise ValueError(f"LLM returned invalid JSON or unexpected structure: {e}") from e

    return _apply_score_override(result)
