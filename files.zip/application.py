"""
app/core/application.py
───────────────────────
FastAPI application factory.  Import `create_app` in main.py.
"""
import contextlib
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.db.session import engine
from app.db.base import Base
from app.api.v1.router import api_router


@contextlib.asynccontextmanager
async def _lifespan(app: FastAPI):
    """Create all DB tables on startup (idempotent)."""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield


def create_app() -> FastAPI:
    app = FastAPI(
        title="AI Resume Analyzer API",
        version=settings.APP_VERSION,
        description=(
            "Analyze resumes against job descriptions using Groq AI. "
            "Includes ATS scoring, skill gap detection, and personalized learning roadmaps."
        ),
        lifespan=_lifespan,
        docs_url="/docs",
        redoc_url="/redoc",
    )

    # ── CORS ────────────────────────────────────────────────────────────────
    origins = (
        ["*"]
        if settings.APP_ENV == "development"
        else settings.ALLOWED_ORIGINS
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ── Routers ─────────────────────────────────────────────────────────────
    app.include_router(api_router)

    @app.get("/", tags=["Health"])
    async def root():
        return {
            "message": "AI Resume Analyzer API is running.",
            "version": settings.APP_VERSION,
            "docs": "/docs",
        }

    @app.get("/health", tags=["Health"])
    async def health():
        return {"status": "ok", "env": settings.APP_ENV}

    return app
