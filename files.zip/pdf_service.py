"""
app/services/pdf_service.py
───────────────────────────
Extract plain text from a PDF supplied as raw bytes.
Uses PyMuPDF (fitz) — no temp files needed.
"""
import fitz  # PyMuPDF


async def extract_text_from_pdf(file_bytes: bytes) -> str:
    try:
        doc = fitz.open(stream=file_bytes, filetype="pdf")
        pages = [doc.load_page(i).get_text("text") for i in range(len(doc))]
        doc.close()
        text = "\n".join(pages).strip()
        if not text:
            raise ValueError(
                "No text could be extracted. "
                "The PDF may be scanned/image-only — try a text-based PDF."
            )
        return text
    except ValueError:
        raise
    except Exception as e:
        raise ValueError(f"Failed to extract text from PDF: {e}") from e
