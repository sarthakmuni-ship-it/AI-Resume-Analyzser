"""
app/services/roadmap_service.py
────────────────────────────────
Calls Groq to generate a personalised learning roadmap for a missing skill.

Design decisions:
  - Each skill gets its own focused prompt (better quality than bulk).
  - The roadmap JSON is fully structured so the frontend can render
    phase cards, resource links, project cards, and quick-win banners.
  - quick_wins tell the user exactly what to paste into their resume RIGHT NOW
    so re-analysis will detect the keyword and improve the ATS score.
"""
from __future__ import annotations
import json
import httpx

from app.core.config import settings

_GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"


def _build_roadmap_prompt(
    skill_name: str,
    skill_priority: str,
    job_description: str,
    resume_text: str,
) -> str:
    return f"""
You are a senior career coach and technical mentor.
A job applicant is missing the skill "{skill_name}" (priority: {skill_priority}) for the following role.

Your task: Generate a practical, week-by-week learning roadmap so the candidate can genuinely acquire this skill.

RULES:
1. Be specific — name actual courses, books, tools, platforms (not vague advice).
2. Free resources MUST have real, working URLs (YouTube, official docs, freeCodeCamp, MDN, etc.).
3. Paid resources should include Udemy, Coursera, Pluralsight, etc. with real course names.
4. Practice projects must be concrete and achievable within the phase's timeline.
5. quick_wins are resume edits the candidate can make TODAY to pass ATS even before fully learning the skill.
   - e.g., "Add 'Exposure to Docker' in your Skills section" or
     "Mention 'containerisation using Docker' in your most recent job bullet"
   - These must use the exact keyword phrasing that ATS systems scan for.
6. Estimate realistic weeks — do not over-promise.
7. Break into 2–4 phases that build on each other logically.

Respond ONLY with a valid JSON object matching this exact schema. No markdown, no preamble.

{{
  "skill_name": "{skill_name}",
  "overview": "2–3 sentence explanation of what this skill is and why it matters for this role",
  "estimated_weeks": 8,
  "phases": [
    {{
      "phase_number": 1,
      "title": "Foundations",
      "duration_weeks": 2,
      "goals": ["Understand core concepts", "Set up local environment"],
      "topics": ["Topic A", "Topic B"],
      "milestone": "What you can demonstrate / build / show after this phase"
    }}
  ],
  "free_resources": [
    {{
      "title": "Exact course/video/doc title",
      "url": "https://actual-url.com",
      "type": "course",
      "platform": "YouTube",
      "description": "One sentence on what it covers"
    }}
  ],
  "paid_resources": [
    {{
      "title": "Exact course title",
      "url": "https://actual-url.com",
      "type": "course",
      "platform": "Udemy",
      "description": "One sentence on what it covers"
    }}
  ],
  "practice_projects": [
    "Build a REST API using this skill that does X",
    "Integrate this skill into your existing portfolio project by adding Y"
  ],
  "quick_wins": [
    {{
      "action": "Add 'Exposure to Docker — containerisation basics' to your Skills section",
      "resume_section": "Skills",
      "expected_impact": "Moves Docker from missing → matched, estimated +10–15 ATS points"
    }}
  ]
}}

Job Description (for context):
{job_description}

Candidate's Current Resume (for context — tailor quick_wins to their actual sections):
{resume_text}

Missing Skill to generate roadmap for: {skill_name}
""".strip()


async def generate_skill_roadmap(
    skill_name: str,
    skill_priority: str,
    job_description: str,
    resume_text: str,
) -> dict:
    """
    Call Groq and return the raw roadmap dict.
    Raises ValueError if the LLM response is malformed.
    """
    headers = {
        "Authorization": f"Bearer {settings.GROQ_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": settings.GROQ_MODEL,
        "messages": [
            {
                "role": "user",
                "content": _build_roadmap_prompt(
                    skill_name, skill_priority, job_description, resume_text
                ),
            }
        ],
        "temperature": 0.3,   # slightly higher for creative/diverse resource suggestions
        "response_format": {"type": "json_object"},
    }

    async with httpx.AsyncClient(timeout=settings.GROQ_TIMEOUT) as client:
        response = await client.post(_GROQ_URL, headers=headers, json=payload)
        response.raise_for_status()

    data = response.json()

    try:
        content = data["choices"][0]["message"]["content"]
        result  = json.loads(content)
    except (json.JSONDecodeError, KeyError) as e:
        raise ValueError(f"Roadmap LLM returned invalid JSON: {e}") from e

    return result
