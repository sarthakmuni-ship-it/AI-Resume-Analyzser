"""
app/api/v1/router.py
─────────────────────
Central v1 router — registers all endpoint routers under /api/v1.
"""
from fastapi import APIRouter

from app.api.v1.endpoints.analysis import router as analysis_router
from app.api.v1.endpoints.roadmap  import router as roadmap_router

api_router = APIRouter(prefix="/api/v1")

api_router.include_router(analysis_router)
api_router.include_router(roadmap_router)
