"""
Entry point — run with:
    uvicorn main:app --reload
"""
from app.core.application import create_app

app = create_app()
