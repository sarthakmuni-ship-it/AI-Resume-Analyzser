"""
app/core/config.py
──────────────────
Single source of truth for all environment-driven configuration.
All other modules import `settings` from here — never from dotenv directly.
"""
from typing import List
from pydantic_settings import BaseSettings
from pydantic import field_validator


class Settings(BaseSettings):
    # ── Database ────────────────────────────────────────────────────────────
    DATABASE_URL: str = "sqlite+aiosqlite:///./resume_analyzer.db"

    # ── Groq / LLM ──────────────────────────────────────────────────────────
    GROQ_API_KEY: str
    GROQ_MODEL: str = "llama3-70b-8192"
    GROQ_TIMEOUT: int = 90          # seconds
    GROQ_TEMPERATURE: float = 0.1

    # ── App ─────────────────────────────────────────────────────────────────
    APP_ENV: str = "development"
    APP_VERSION: str = "2.0.0"

    # ── CORS ─────────────────────────────────────────────────────────────────
    ALLOWED_ORIGINS: List[str] = ["http://localhost:5173", "http://localhost:3000"]

    @field_validator("ALLOWED_ORIGINS", mode="before")
    @classmethod
    def parse_origins(cls, v):
        if isinstance(v, str):
            import json
            return json.loads(v)
        return v

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
