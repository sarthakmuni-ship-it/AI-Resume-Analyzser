"""
app/services/txt_service.py
────────────────────────────
Decode a plain-text file supplied as raw bytes.
Tries UTF-8 first, falls back to latin-1.
"""


async def extract_text_from_txt(file_bytes: bytes) -> str:
    for encoding in ("utf-8", "latin-1"):
        try:
            text = file_bytes.decode(encoding).strip()
            if text:
                return text
        except (UnicodeDecodeError, ValueError):
            continue
    raise ValueError("Failed to decode text file: unsupported encoding.")
