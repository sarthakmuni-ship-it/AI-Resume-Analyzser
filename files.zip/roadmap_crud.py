"""
app/utils/roadmap_crud.py
──────────────────────────
DB operations for SkillRoadmap.
Includes a cache-check so we never regenerate a roadmap for the same
analysis_id + skill_name pair.
"""
from __future__ import annotations
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from app.models.roadmap import SkillRoadmap


async def get_roadmap(
    db: AsyncSession,
    analysis_id: int,
    skill_name: str,
) -> SkillRoadmap | None:
    """Return cached roadmap if it already exists."""
    result = await db.execute(
        select(SkillRoadmap).filter(
            SkillRoadmap.analysis_id == analysis_id,
            SkillRoadmap.skill_name  == skill_name,
        )
    )
    return result.scalars().first()


async def get_roadmaps_for_analysis(
    db: AsyncSession,
    analysis_id: int,
) -> list[SkillRoadmap]:
    result = await db.execute(
        select(SkillRoadmap)
        .filter(SkillRoadmap.analysis_id == analysis_id)
        .order_by(SkillRoadmap.skill_priority)
    )
    return result.scalars().all()


async def save_roadmap(
    db: AsyncSession,
    analysis_id: int,
    skill_priority: str,
    roadmap_data: dict,
) -> SkillRoadmap:
    record = SkillRoadmap(
        analysis_id       = analysis_id,
        skill_name        = roadmap_data.get("skill_name", ""),
        skill_priority    = skill_priority,
        overview          = roadmap_data.get("overview", ""),
        estimated_weeks   = roadmap_data.get("estimated_weeks", 0),
        phases            = roadmap_data.get("phases", []),
        free_resources    = roadmap_data.get("free_resources", []),
        paid_resources    = roadmap_data.get("paid_resources", []),
        practice_projects = roadmap_data.get("practice_projects", []),
        quick_wins        = roadmap_data.get("quick_wins", []),
    )
    db.add(record)
    await db.commit()
    await db.refresh(record)
    return record


async def delete_roadmap(db: AsyncSession, record: SkillRoadmap) -> None:
    await db.delete(record)
    await db.commit()
