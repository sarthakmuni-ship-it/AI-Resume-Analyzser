"""
app/api/v1/endpoints/roadmap.py
────────────────────────────────
Endpoints:
  POST   /api/v1/roadmap/{analysis_id}/{skill_name}  — generate (or return cached) roadmap
  GET    /api/v1/roadmap/{analysis_id}               — list all roadmaps for an analysis
  GET    /api/v1/roadmap/{analysis_id}/{skill_name}  — fetch a single roadmap
  DELETE /api/v1/roadmap/item/{roadmap_id}           — delete a roadmap record
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_db
from app.schemas import RoadmapAPIResponse, RoadmapListResponse, DeleteResponse
from app.services.roadmap_service import generate_skill_roadmap
from app.utils.analysis_crud import get_analysis_by_id
from app.utils.roadmap_crud import (
    delete_roadmap,
    get_roadmap,
    get_roadmaps_for_analysis,
    save_roadmap,
)
from app.models.roadmap import SkillRoadmap

router = APIRouter(prefix="/roadmap", tags=["Roadmap"])


# ── POST /roadmap/{analysis_id}/{skill_name}  ────────────────────────────────

@router.post(
    "/{analysis_id}/{skill_name}",
    response_model=RoadmapAPIResponse,
    summary="Generate learning roadmap for a missing skill",
)
async def create_roadmap(
    analysis_id: int,
    skill_name:  str,
    db: AsyncSession = Depends(get_db),
):
    """
    Generate a personalised learning roadmap for `skill_name` from the
    missing_skills of the given analysis.

    Results are CACHED — calling this endpoint twice for the same
    analysis_id + skill_name returns the stored result without a second LLM call.
    """
    # 1. Verify parent analysis exists
    analysis = await get_analysis_by_id(db, analysis_id)
    if not analysis:
        raise HTTPException(status_code=404, detail=f"Analysis {analysis_id} not found.")

    # 2. Return cached roadmap if available
    cached = await get_roadmap(db, analysis_id, skill_name)
    if cached:
        return {"status": "success (cached)", "data": cached}

    # 3. Verify skill is actually in the missing_skills list
    missing: list = analysis.missing_skills or []
    skill_entry = next(
        (s for s in missing if s.get("skill", "").lower() == skill_name.lower()),
        None,
    )
    if not skill_entry:
        raise HTTPException(
            status_code=404,
            detail=(
                f"Skill '{skill_name}' not found in missing_skills for analysis {analysis_id}. "
                "Only skills identified as missing can have roadmaps generated."
            ),
        )

    skill_priority = skill_entry.get("priority", "medium")

    # 4. Call LLM
    try:
        roadmap_data = await generate_skill_roadmap(
            skill_name      = skill_name,
            skill_priority  = skill_priority,
            job_description = analysis.job_description,
            resume_text     = "",  # resume not stored in DB; JD context is sufficient
        )
    except ValueError as e:
        raise HTTPException(status_code=502, detail=str(e)) from e
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) from e

    # 5. Persist and return
    record = await save_roadmap(db, analysis_id, skill_priority, roadmap_data)
    return {"status": "success", "data": record}


# ── GET /roadmap/{analysis_id}  ──────────────────────────────────────────────

@router.get(
    "/{analysis_id}",
    response_model=RoadmapListResponse,
    summary="List all roadmaps for an analysis",
)
async def list_roadmaps(analysis_id: int, db: AsyncSession = Depends(get_db)):
    analysis = await get_analysis_by_id(db, analysis_id)
    if not analysis:
        raise HTTPException(status_code=404, detail=f"Analysis {analysis_id} not found.")

    roadmaps = await get_roadmaps_for_analysis(db, analysis_id)
    return {"status": "success", "data": roadmaps}


# ── GET /roadmap/{analysis_id}/{skill_name}  ─────────────────────────────────

@router.get(
    "/{analysis_id}/{skill_name}",
    response_model=RoadmapAPIResponse,
    summary="Fetch a specific roadmap",
)
async def get_single_roadmap(
    analysis_id: int,
    skill_name:  str,
    db: AsyncSession = Depends(get_db),
):
    roadmap = await get_roadmap(db, analysis_id, skill_name)
    if not roadmap:
        raise HTTPException(
            status_code=404,
            detail=(
                f"No roadmap for '{skill_name}' under analysis {analysis_id}. "
                "POST to this URL first to generate one."
            ),
        )
    return {"status": "success", "data": roadmap}


# ── DELETE /roadmap/item/{roadmap_id}  ───────────────────────────────────────

@router.delete(
    "/item/{roadmap_id}",
    response_model=DeleteResponse,
    summary="Delete a roadmap",
)
async def delete_roadmap_item(roadmap_id: int, db: AsyncSession = Depends(get_db)):
    record = await db.get(SkillRoadmap, roadmap_id)
    if not record:
        raise HTTPException(status_code=404, detail="Roadmap not found.")
    await delete_roadmap(db, record)
    return {"status": "success", "message": f"Roadmap {roadmap_id} deleted."}
