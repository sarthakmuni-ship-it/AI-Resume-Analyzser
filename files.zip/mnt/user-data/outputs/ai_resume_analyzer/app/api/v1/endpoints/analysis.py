"""
app/api/v1/endpoints/analysis.py
─────────────────────────────────
Endpoints:
  POST   /api/v1/analyze/          — upload PDF or TXT file
  POST   /api/v1/analyze/text      — paste raw resume text
  GET    /api/v1/analyze/history   — all past analyses
  GET    /api/v1/analyze/history/{id} — single analysis
  DELETE /api/v1/analyze/history/{id} — delete one record
"""
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_db
from app.schemas import AnalysisAPIResponse, HistoryListResponse, HistoryRecord, DeleteResponse
from app.services.llm_service import analyze_resume_with_groq
from app.services.pdf_service import extract_text_from_pdf
from app.services.txt_service import extract_text_from_txt
from app.utils.analysis_crud import (
    delete_analysis,
    get_all_analyses,
    get_analysis_by_id,
    save_analysis,
)

router = APIRouter(prefix="/analyze", tags=["Analysis"])

_ALLOWED_EXTENSIONS = (".pdf", ".txt")


# ── POST /analyze/  ──────────────────────────────────────────────────────────

@router.post("/", response_model=AnalysisAPIResponse, summary="Analyze resume file")
async def analyze_resume_file(
    file: UploadFile = File(..., description="PDF or TXT resume file"),
    job_description: str = Form(..., description="Full job description text"),
    db: AsyncSession = Depends(get_db),
):
    """
    Upload a PDF or TXT resume and a job description.
    Returns ATS score, skill gaps, feedback, and rewritten bullets.
    """
    filename_lower = file.filename.lower() if file.filename else ""
    if not any(filename_lower.endswith(ext) for ext in _ALLOWED_EXTENSIONS):
        raise HTTPException(
            status_code=400,
            detail=f"Only {', '.join(_ALLOWED_EXTENSIONS)} files are supported.",
        )

    try:
        file_bytes = await file.read()

        if filename_lower.endswith(".pdf"):
            resume_text = await extract_text_from_pdf(file_bytes)
        else:
            resume_text = await extract_text_from_txt(file_bytes)

        if not resume_text:
            raise HTTPException(
                status_code=422,
                detail="Could not extract any text. Ensure the PDF is not scanned/image-only.",
            )

        analysis = await analyze_resume_with_groq(resume_text, job_description)
        record   = await save_analysis(db, file.filename, job_description, analysis)

        return {
            "status":         "success",
            "data":           analysis,
            "history_id":     record.id,
            "extracted_text": resume_text,
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) from e


# ── POST /analyze/text  ──────────────────────────────────────────────────────

@router.post("/text", response_model=AnalysisAPIResponse, summary="Analyze pasted resume text")
async def analyze_resume_text(
    resume_text: str      = Form(..., description="Raw resume text"),
    job_description: str  = Form(..., description="Full job description text"),
    original_filename: str = Form("Manual Entry", description="Optional label"),
    db: AsyncSession = Depends(get_db),
):
    """
    Accepts raw resume text instead of a file upload.
    Useful for the in-browser editor / copy-paste flow.
    """
    if not resume_text.strip():
        raise HTTPException(status_code=400, detail="resume_text cannot be empty.")

    try:
        analysis = await analyze_resume_with_groq(resume_text, job_description)
        record   = await save_analysis(
            db, f"{original_filename} (Edited)", job_description, analysis
        )
        return {
            "status":     "success",
            "data":       analysis,
            "history_id": record.id,
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) from e


# ── GET /analyze/history  ────────────────────────────────────────────────────

@router.get("/history", response_model=HistoryListResponse, summary="List all analyses")
async def list_history(db: AsyncSession = Depends(get_db)):
    """Returns all analysis records sorted newest-first."""
    try:
        records = await get_all_analyses(db)
        return {"status": "success", "data": records}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) from e


# ── GET /analyze/history/{id}  ───────────────────────────────────────────────

@router.get(
    "/history/{history_id}",
    response_model=HistoryRecord,
    summary="Get single analysis",
)
async def get_history_item(history_id: int, db: AsyncSession = Depends(get_db)):
    record = await get_analysis_by_id(db, history_id)
    if not record:
        raise HTTPException(status_code=404, detail="Analysis record not found.")
    return record


# ── DELETE /analyze/history/{id}  ────────────────────────────────────────────

@router.delete(
    "/history/{history_id}",
    response_model=DeleteResponse,
    summary="Delete an analysis",
)
async def delete_history_item(history_id: int, db: AsyncSession = Depends(get_db)):
    record = await get_analysis_by_id(db, history_id)
    if not record:
        raise HTTPException(status_code=404, detail="Analysis record not found.")
    try:
        await delete_analysis(db, record)
        return {"status": "success", "message": f"Record {history_id} deleted."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) from e
